import React, { createContext, useContext, useState } from 'react';

interface HealthData {
  age: number;
  gender: 'masculino' | 'feminino';
  height: number;
  currentWeight: number;
  targetWeight: number;
  healthConditions: string[];
  medications: string[];
  allergies: string[];
  dietaryPreferences: string[];
  physicalLimitations: string[];
  activityLevel: 'sedentario' | 'leve' | 'moderado' | 'intenso';
  currentHabits: string;
  weightLossTimeframe: string;
}

interface UserContextType {
  healthData: HealthData | null;
  updateHealthData: (data: HealthData) => void;
  completeOnboarding: () => void;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export const useUser = () => {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
};

export const UserProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [healthData, setHealthData] = useState<HealthData | null>(null);

  const updateHealthData = (data: HealthData) => {
    setHealthData(data);
    localStorage.setItem('nutrivida_health_data', JSON.stringify(data));
  };

  const completeOnboarding = () => {
    const storedUser = localStorage.getItem('nutrivida_user');
    if (storedUser) {
      const user = JSON.parse(storedUser);
      user.hasCompletedOnboarding = true;
      localStorage.setItem('nutrivida_user', JSON.stringify(user));
    }
  };

  const value = {
    healthData,
    updateHealthData,
    completeOnboarding
  };

  return <UserContext.Provider value={value}>{children}</UserContext.Provider>;
};