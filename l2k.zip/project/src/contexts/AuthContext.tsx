import React, { createContext, useContext, useState, useEffect } from 'react';

interface User {
  id: string;
  name: string;
  email: string;
  phone?: string;
  hasCompletedOnboarding: boolean;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<boolean>;
  register: (name: string, email: string, phone: string, password: string) => Promise<boolean>;
  logout: () => void;
  isLoading: boolean;
  forgotPassword: (email: string) => Promise<boolean>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simular verificação de token armazenado
    const storedUser = localStorage.getItem('nutrivida_user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    setIsLoading(true);
    
    // Simulação de API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Simular login bem-sucedido
    const mockUser: User = {
      id: '1',
      name: 'Maria Silva',
      email: email,
      phone: '(11) 99999-9999',
      hasCompletedOnboarding: email === 'maria@exemplo.com'
    };
    
    setUser(mockUser);
    localStorage.setItem('nutrivida_user', JSON.stringify(mockUser));
    setIsLoading(false);
    return true;
  };

  const register = async (name: string, email: string, phone: string, password: string): Promise<boolean> => {
    setIsLoading(true);
    
    // Simulação de API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const newUser: User = {
      id: Date.now().toString(),
      name,
      email,
      phone,
      hasCompletedOnboarding: false
    };
    
    setUser(newUser);
    localStorage.setItem('nutrivida_user', JSON.stringify(newUser));
    setIsLoading(false);
    return true;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('nutrivida_user');
  };

  const forgotPassword = async (email: string): Promise<boolean> => {
    // Simulação de envio de email
    await new Promise(resolve => setTimeout(resolve, 1000));
    return true;
  };

  const value = {
    user,
    login,
    register,
    logout,
    isLoading,
    forgotPassword
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};