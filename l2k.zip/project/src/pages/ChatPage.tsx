import React, { useState, useRef, useEffect } from 'react';
import Layout from '../components/Layout';
import { Send, Bot, User, Coffee, Sun, Moon, Apple } from 'lucide-react';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'ai' | 'nutritionist';
  timestamp: Date;
  isNewDiet?: boolean;
}

const ChatPage: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: 'Olá! Sou sua assistente nutricional inteligente. Como posso ajudá-la hoje?',
      sender: 'ai',
      timestamp: new Date()
    }
  ]);
  const [newMessage, setNewMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [dietCounter, setDietCounter] = useState({
    cafe: 0,
    almoco: 0,
    lanche: 0,
    jantar: 0
  });

  const mealButtons = [
    { id: 'cafe', label: 'Nova Dieta - Café', icon: Coffee, message: 'Gere uma nova dieta para o café da manhã' },
    { id: 'almoco', label: 'Nova Dieta - Almoço', icon: Sun, message: 'Gere uma nova dieta para o almoço' },
    { id: 'lanche', label: 'Nova Dieta - Lanche', icon: Apple, message: 'Gere uma nova dieta para o lanche' },
    { id: 'jantar', label: 'Nova Dieta - Jantar', icon: Moon, message: 'Gere uma nova dieta para o jantar' }
  ];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async (messageText?: string) => {
    const textToSend = messageText || newMessage;
    if (!textToSend.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: textToSend,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    if (!messageText) setNewMessage('');
    setIsTyping(true);

    // Simular resposta da IA
    setTimeout(() => {
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: getAIResponse(textToSend),
        sender: 'ai',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, aiResponse]);
      setIsTyping(false);
    }, 1500);
  };

  const handleMealButtonClick = (meal: typeof mealButtons[0]) => {
    // Incrementa o contador para essa refeição
    const mealType = meal.id as keyof typeof dietCounter;
    setDietCounter(prev => ({
      ...prev,
      [mealType]: prev[mealType] + 1
    }));
    
    handleSendMessage(meal.message);
  };

  const getAIResponse = (userMessage: string): string => {
    const message = userMessage.toLowerCase();
    
    if (message.includes('gere uma nova dieta para o café') || (message.includes('café da manhã') && message.includes('gere'))) {
      return generateNewDiet('cafe');
    }
    
    if (message.includes('gere uma nova dieta para o almoço') || (message.includes('almoço') && message.includes('gere'))) {
      return generateNewDiet('almoco');
    }
    
    if (message.includes('gere uma nova dieta para o lanche') || (message.includes('lanche') && message.includes('gere'))) {
      return generateNewDiet('lanche');
    }
    
    if (message.includes('gere uma nova dieta para o jantar') || (message.includes('jantar') && message.includes('gere'))) {
      return generateNewDiet('jantar');
    }
    
    // Respostas para dúvidas gerais (sem gerar nova dieta)
    if (message.includes('café da manhã') || message.includes('cafe')) {
      return 'Para o café da manhã, recomendo: 1 fatia de pão integral + 1 ovo mexido + 1 copo de leite desnatado + 1/2 mamão. Isso fornece proteínas, fibras e energia para começar bem o dia. Quer uma nova opção de dieta? Use o botão "Nova Dieta - Café"!';
    }
    
    if (message.includes('almoço')) {
      return 'Seu almoço ideal inclui: 3 col. sopa de arroz integral + 1 concha de feijão + 100g de proteína (frango/peixe) + salada verde à vontade + legumes refogados. Quer uma nova opção? Use o botão "Nova Dieta - Almoço"!';
    }
    
    if (message.includes('lanche')) {
      return 'Para os lanches, sugiro opções leves: manhã (1 fruta + castanhas) e tarde (iogurte natural + granola sem açúcar). Quer uma nova opção? Use o botão "Nova Dieta - Lanche"!';
    }
    
    if (message.includes('jantar')) {
      return 'O jantar deve ser mais leve: 100g de peixe assado + 2 col. sopa de quinoa + salada verde + 1 col. sopa de azeite. Quer uma nova opção? Use o botão "Nova Dieta - Jantar"!';
    }
    
    if (message.includes('peso') || message.includes('emagrecer')) {
      return 'Para um emagrecimento saudável, é importante manter um déficit calórico moderado. Baseado no seu perfil, recomendo focar em proteínas magras, vegetais e reduzir carboidratos refinados. Gostaria de sugestões específicas de alimentos?';
    }
    
    if (message.includes('água') || message.includes('hidratação')) {
      return 'Excelente pergunta! Para sua idade e peso, recomendo cerca de 2 litros de água por dia. Você pode incluir chás sem açúcar e água com limão. Evite bebidas açucaradas e refrigerantes.';
    }
    
    if (message.includes('exercício') || message.includes('atividade')) {
      return 'Atividade física é fundamental! Para pessoas acima de 50 anos, recomendo caminhadas de 30 minutos, 5 vezes por semana. Exercícios de resistência leve também são benéficos. Sempre consulte seu médico antes de iniciar novos exercícios.';
    }
    
    if (message.includes('substituir') || message.includes('trocar')) {
      return 'Posso ajudar com substituições! Por exemplo: arroz branco → quinoa ou arroz integral; açúcar → stevia ou xilitol; leite integral → leite desnatado. Qual alimento específico você gostaria de substituir?';
    }
    
    return 'Entendo sua dúvida. Com base no seu plano alimentar personalizado, posso oferecer orientações específicas. Para questões mais complexas sobre sua saúde, nossa nutricionista humana pode te ajudar melhor. Gostaria que eu a conecte com ela?';
  };

  const generateNewDiet = (mealType: string): string => {
    const currentCount = dietCounter[mealType as keyof typeof dietCounter];
    
    const diets = {
      cafe: [
        '🍳 **NOVA DIETA - CAFÉ DA MANHÃ #' + (currentCount + 1) + '**\n\n• 2 fatias de pão integral\n• 1 ovo cozido\n• 1 copo de leite de amêndoas\n• 1 banana pequena\n• 1 col. chá de mel\n\n**Calorias:** ~280 kcal\n**Preparo:** 5 minutos\n\n💡 *Esta combinação oferece fibras, proteínas e energia sustentada!*',
        '🥐 **NOVA DIETA - CAFÉ DA MANHÃ #' + (currentCount + 1) + '**\n\n• 1 tapioca média\n• 2 col. sopa de queijo cottage\n• 1 fatia de peito de peru\n• 1/2 abacate pequeno\n• Chá verde sem açúcar\n\n**Calorias:** ~320 kcal\n**Preparo:** 8 minutos\n\n💡 *Rica em proteínas e gorduras boas para saciedade!*',
        '🥣 **NOVA DIETA - CAFÉ DA MANHÃ #' + (currentCount + 1) + '**\n\n• 1 tigela de aveia\n• 1 col. sopa de chia\n• 1 maçã picada\n• 10 amêndoas\n• 1 copo de leite desnatado\n\n**Calorias:** ~350 kcal\n**Preparo:** 3 minutos\n\n💡 *Fibras e ômega-3 para um dia energético!*'
      ],
      almoco: [
        '🍽️ **NOVA DIETA - ALMOÇO #' + (currentCount + 1) + '**\n\n• 120g de salmão grelhado\n• 3 col. sopa de arroz integral\n• Salada de rúcula e tomate\n• 2 col. sopa de lentilha\n• 1 col. sopa de azeite\n\n**Calorias:** ~480 kcal\n**Preparo:** 20 minutos\n\n💡 *Ômega-3 e proteínas de alta qualidade!*',
        '🥘 **NOVA DIETA - ALMOÇO #' + (currentCount + 1) + '**\n\n• 100g de peito de frango\n• 4 col. sopa de quinoa\n• Brócolis e cenoura refogados\n• Salada de folhas verdes\n• Molho de iogurte natural\n\n**Calorias:** ~420 kcal\n**Preparo:** 25 minutos\n\n💡 *Proteína completa com carboidrato de baixo índice glicêmico!*',
        '🐟 **NOVA DIETA - ALMOÇO #' + (currentCount + 1) + '**\n\n• 150g de tilápia assada\n• 3 col. sopa de batata doce\n• Abobrinha e berinjela grelhadas\n• Salada de pepino\n• Temperos naturais\n\n**Calorias:** ~390 kcal\n**Preparo:** 30 minutos\n\n💡 *Peixe magro com carboidrato complexo!*'
      ],
      lanche: [
        '🍎 **NOVA DIETA - LANCHE #' + (currentCount + 1) + '**\n\n• 1 iogurte grego natural\n• 1 col. sopa de granola sem açúcar\n• 5 morangos\n• 1 col. chá de mel\n• Água de coco (200ml)\n\n**Calorias:** ~180 kcal\n**Preparo:** 2 minutos\n\n💡 *Probióticos e antioxidantes para sua saúde!*',
        '🥜 **NOVA DIETA - LANCHE #' + (currentCount + 1) + '**\n\n• 1 pera média\n• 8 castanhas do Brasil\n• 1 fatia de queijo branco\n• Chá de camomila\n\n**Calorias:** ~200 kcal\n**Preparo:** 1 minuto\n\n💡 *Selênio e fibras para o metabolismo!*',
        '🥤 **NOVA DIETA - LANCHE #' + (currentCount + 1) + '**\n\n• Vitamina: 1 banana + 200ml leite desnatado + 1 col. sopa de aveia\n• 3 biscoitos integrais\n\n**Calorias:** ~220 kcal\n**Preparo:** 3 minutos\n\n💡 *Energia rápida e duradoura!*'
      ],
      jantar: [
        '🌙 **NOVA DIETA - JANTAR #' + (currentCount + 1) + '**\n\n• Omelete com 2 ovos\n• Espinafre e tomate\n• 2 fatias de pão integral\n• Salada de alface\n• Chá de erva-doce\n\n**Calorias:** ~320 kcal\n**Preparo:** 10 minutos\n\n💡 *Leve e nutritivo para uma boa digestão!*',
        '🥗 **NOVA DIETA - JANTAR #' + (currentCount + 1) + '**\n\n• 100g de peito de frango desfiado\n• Salada completa (alface, tomate, pepino, cenoura)\n• 2 col. sopa de grão de bico\n• Molho de limão e ervas\n\n**Calorias:** ~280 kcal\n**Preparo:** 15 minutos\n\n💡 *Proteína magra com fibras e vitaminas!*',
        '🍲 **NOVA DIETA - JANTAR #' + (currentCount + 1) + '**\n\n• Sopa de legumes com frango\n• 2 fatias de torrada integral\n• 1 col. sopa de abacate\n• Chá de melissa\n\n**Calorias:** ~250 kcal\n**Preparo:** 20 minutos\n\n💡 *Hidratante e reconfortante para a noite!*'
      ]
    };

    const mealOptions = diets[mealType as keyof typeof diets];
    const randomIndex = Math.floor(Math.random() * mealOptions.length);
    
    return mealOptions[randomIndex] + '\n\n🔄 *Clique novamente no botão para gerar outra opção!*';
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <Layout>
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 h-[calc(100vh-200px)] flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center space-x-3">
            <div className="bg-green-100 p-2 rounded-full">
              <Bot className="h-6 w-6 text-green-600" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Assistente Nutricional IA</h2>
              <p className="text-gray-600">Online • Responde em segundos</p>
            </div>
          </div>
        </div>

        {/* Quick Meal Selection Buttons */}
        <div className="p-4 border-b border-gray-200 bg-gray-50">
          <p className="text-lg font-medium text-gray-700 mb-3">🍽️ Gerar nova dieta para:</p>
          <div className="grid grid-cols-2 gap-2">
            {mealButtons.map((meal) => {
              const Icon = meal.icon;
              return (
                <button
                  key={meal.id}
                  onClick={() => handleMealButtonClick(meal)}
                  disabled={isTyping}
                  className="flex items-center space-x-2 p-3 bg-white border border-gray-200 rounded-lg hover:bg-green-50 hover:border-green-300 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Icon className="h-5 w-5 text-green-600" />
                  <span className="text-sm text-gray-700">{meal.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`flex items-start space-x-2 max-w-xs lg:max-w-md ${
                message.sender === 'user' ? 'flex-row-reverse space-x-reverse' : ''
              }`}>
                <div className={`p-2 rounded-full ${
                  message.sender === 'user' 
                    ? 'bg-green-100' 
                    : message.sender === 'ai' 
                    ? 'bg-blue-100' 
                    : 'bg-purple-100'
                }`}>
                  {message.sender === 'user' ? (
                    <User className="h-5 w-5 text-green-600" />
                  ) : (
                    <Bot className="h-5 w-5 text-blue-600" />
                  )}
                </div>
                <div className={`p-3 rounded-lg ${
                  message.sender === 'user'
                    ? 'bg-green-600 text-white'
                    : message.isNewDiet 
                    ? 'bg-green-50 border border-green-200 text-gray-900'
                    : 'bg-gray-100 text-gray-900'
                }`}>
                  <div className="text-lg whitespace-pre-line">{message.text}</div>
                  <p className={`text-sm mt-1 ${
                    message.sender === 'user' ? 'text-green-100' : 'text-gray-500'
                  }`}>
                    {message.timestamp.toLocaleTimeString('pt-BR', { 
                      hour: '2-digit', 
                      minute: '2-digit' 
                    })}
                  </p>
                </div>
              </div>
            </div>
          ))}

          {isTyping && (
            <div className="flex justify-start">
              <div className="flex items-start space-x-2">
                <div className="bg-blue-100 p-2 rounded-full">
                  <Bot className="h-5 w-5 text-blue-600" />
                </div>
                <div className="bg-gray-100 p-3 rounded-lg">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  </div>
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="p-4 border-t border-gray-200">
          <div className="flex space-x-2">
            <input
              type="text"
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Digite sua pergunta sobre nutrição..."
              className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 text-lg"
            />
            <button
              onClick={handleSendMessage}
              disabled={!newMessage.trim() || isTyping}
              className="bg-green-600 text-white p-3 rounded-lg hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send className="h-5 w-5" />
            </button>
          </div>
          <p className="text-sm text-gray-500 mt-2">
            💡 Dica: Pergunte sobre substituições de alimentos, dúvidas sobre seu plano ou hábitos saudáveis
          </p>
        </div>
      </div>
    </Layout>
  );
};

export default ChatPage;