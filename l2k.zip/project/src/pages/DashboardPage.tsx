import React from 'react';
import Layout from '../components/Layout';
import { useAuth } from '../contexts/AuthContext';
import { TrendingDown, Calendar, MessageCircle, FileText, Target, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';

const DashboardPage: React.FC = () => {
  const { user } = useAuth();

  // Dados simulados
  const currentWeight = 72;
  const targetWeight = 65;
  const weightLoss = 3;
  const daysOnPlan = 15;

  return (
    <Layout>
      <div className="space-y-6">
        {/* Welcome Section */}
        <div className="bg-gradient-to-r from-green-600 to-green-700 rounded-lg p-6 text-white">
          <h1 className="text-3xl font-bold mb-2">Olá, {user?.name}!</h1>
          <p className="text-xl text-green-100">
            Você está indo muito bem! Continue assim e alcance seus objetivos.
          </p>
        </div>

        {/* Progress Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-lg">Peso Atual</p>
                <p className="text-3xl font-bold text-gray-900">{currentWeight}kg</p>
              </div>
              <TrendingDown className="h-8 w-8 text-green-600" />
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-lg">Meta</p>
                <p className="text-3xl font-bold text-gray-900">{targetWeight}kg</p>
              </div>
              <Target className="h-8 w-8 text-blue-600" />
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-lg">Perdeu</p>
                <p className="text-3xl font-bold text-green-600">-{weightLoss}kg</p>
              </div>
              <TrendingDown className="h-8 w-8 text-green-600" />
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-lg">Dias no Plano</p>
                <p className="text-3xl font-bold text-gray-900">{daysOnPlan}</p>
              </div>
              <Clock className="h-8 w-8 text-purple-600" />
            </div>
          </div>
        </div>

        {/* Progress Chart */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Progresso de Peso</h2>
          <div className="h-64 flex items-end justify-center space-x-2">
            {/* Simulação de gráfico simples */}
            {[75, 74, 73, 72, 72].map((weight, index) => (
              <div key={index} className="flex flex-col items-center">
                <div 
                  className="bg-green-600 w-12 rounded-t"
                  style={{ height: `${(weight - 65) * 8}px` }}
                ></div>
                <span className="text-sm text-gray-600 mt-2">Sem {index + 1}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Link
            to="/meu-plano"
            className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-shadow"
          >
            <div className="flex items-center space-x-4">
              <div className="bg-green-100 p-3 rounded-lg">
                <FileText className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <h3 className="text-xl font-semibold text-gray-900">Meu Plano de Hoje</h3>
                <p className="text-gray-600">Ver refeições planejadas</p>
              </div>
            </div>
          </Link>

          <Link
            to="/chat"
            className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-shadow"
          >
            <div className="flex items-center space-x-4">
              <div className="bg-blue-100 p-3 rounded-lg">
                <MessageCircle className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <h3 className="text-xl font-semibold text-gray-900">Conversar com IA</h3>
                <p className="text-gray-600">Tire suas dúvidas</p>
              </div>
            </div>
          </Link>

          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center space-x-4">
              <div className="bg-purple-100 p-3 rounded-lg">
                <Calendar className="h-6 w-6 text-purple-600" />
              </div>
              <div>
                <h3 className="text-xl font-semibold text-gray-900">Próxima Consulta</h3>
                <p className="text-gray-600">25/12 às 14:00</p>
              </div>
            </div>
          </div>
        </div>

        {/* Daily Tip */}
        <div className="bg-yellow-50 border border-yellow-200 p-6 rounded-lg">
          <h3 className="text-xl font-semibold text-yellow-800 mb-2">💡 Dica do Dia</h3>
          <p className="text-lg text-yellow-700">
            Beba um copo de água antes de cada refeição. Isso ajuda na digestão e pode reduzir a sensação de fome.
          </p>
        </div>
      </div>
    </Layout>
  );
};

export default DashboardPage;