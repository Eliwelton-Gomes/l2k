import React, { useState } from 'react';
import Layout from '../components/Layout';
import { Calendar, Download, Clock, Utensils } from 'lucide-react';

const MyPlanPage: React.FC = () => {
  const [selectedDay, setSelectedDay] = useState('segunda');

  const weekDays = [
    { key: 'segunda', label: 'Segunda' },
    { key: 'terca', label: 'Terça' },
    { key: 'quarta', label: 'Quarta' },
    { key: 'quinta', label: 'Quinta' },
    { key: 'sexta', label: 'Sexta' },
    { key: 'sabado', label: 'Sábado' },
    { key: 'domingo', label: 'Domingo' }
  ];

  const mealPlan = {
    'cafe-manha': {
      title: 'Café da Manhã',
      time: '07:00',
      icon: '☕',
      foods: [
        '1 fatia de pão integral',
        '1 ovo mexido com pouco óleo',
        '1 copo de leite desnatado',
        '1/2 mamão papaya'
      ],
      calories: '320 kcal'
    },
    'lanche-manha': {
      title: 'Lanche da Manhã',
      time: '10:00',
      icon: '🍎',
      foods: [
        '1 maçã média',
        '10 castanhas do Pará'
      ],
      calories: '180 kcal'
    },
    'almoco': {
      title: 'Almoço',
      time: '12:30',
      icon: '🍽️',
      foods: [
        '3 col. sopa de arroz integral',
        '1 concha de feijão',
        '100g de peito de frango grelhado',
        'Salada verde à vontade',
        '2 col. sopa de legumes refogados'
      ],
      calories: '450 kcal'
    },
    'lanche-tarde': {
      title: 'Lanche da Tarde',
      time: '15:30',
      icon: '🥤',
      foods: [
        '1 iogurte natural desnatado',
        '1 col. sopa de granola sem açúcar'
      ],
      calories: '150 kcal'
    },
    'jantar': {
      title: 'Jantar',
      time: '19:00',
      icon: '🥗',
      foods: [
        '100g de peixe assado',
        '2 col. sopa de quinoa',
        'Salada de folhas verdes',
        '1 col. sopa de azeite extra virgem'
      ],
      calories: '380 kcal'
    },
    'ceia': {
      title: 'Ceia',
      time: '21:30',
      icon: '🥛',
      foods: [
        '1 copo de chá de camomila',
        '2 biscoitos integrais'
      ],
      calories: '80 kcal'
    }
  };

  const totalCalories = Object.values(mealPlan).reduce((total, meal) => {
    return total + parseInt(meal.calories.replace(' kcal', ''));
  }, 0);

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Meu Plano Alimentar</h1>
            <p className="text-lg text-gray-600">Plano personalizado para emagrecimento saudável</p>
          </div>
          <button className="flex items-center space-x-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
            <Download className="h-5 w-5" />
            <span>Baixar PDF</span>
          </button>
        </div>

        {/* Week Navigation */}
        <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center space-x-2 mb-4">
            <Calendar className="h-5 w-5 text-gray-600" />
            <span className="text-lg font-medium text-gray-700">Selecione o dia da semana:</span>
          </div>
          <div className="flex space-x-2 overflow-x-auto">
            {weekDays.map((day) => (
              <button
                key={day.key}
                onClick={() => setSelectedDay(day.key)}
                className={`px-4 py-2 rounded-lg text-lg font-medium whitespace-nowrap ${
                  selectedDay === day.key
                    ? 'bg-green-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {day.label}
              </button>
            ))}
          </div>
        </div>

        {/* Daily Summary */}
        <div className="bg-gradient-to-r from-green-600 to-green-700 text-white p-6 rounded-lg">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-2xl font-bold">Resumo do Dia</h2>
              <p className="text-green-100">Plano balanceado para seus objetivos</p>
            </div>
            <div className="text-right">
              <p className="text-3xl font-bold">{totalCalories}</p>
              <p className="text-green-100">calorias totais</p>
            </div>
          </div>
        </div>

        {/* Meals */}
        <div className="grid gap-6">
          {Object.entries(mealPlan).map(([key, meal]) => (
            <div key={key} className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <span className="text-2xl">{meal.icon}</span>
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900">{meal.title}</h3>
                    <div className="flex items-center space-x-2 text-gray-600">
                      <Clock className="h-4 w-4" />
                      <span>{meal.time}</span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-lg font-semibold text-green-600">{meal.calories}</span>
                </div>
              </div>
              
              <div className="space-y-2">
                {meal.foods.map((food, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <Utensils className="h-4 w-4 text-gray-400" />
                    <span className="text-lg text-gray-700">{food}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Tips */}
        <div className="bg-blue-50 border border-blue-200 p-6 rounded-lg">
          <h3 className="text-xl font-semibold text-blue-800 mb-3">💡 Dicas Importantes</h3>
          <ul className="space-y-2 text-lg text-blue-700">
            <li>• Beba pelo menos 2 litros de água ao longo do dia</li>
            <li>• Mastigue bem os alimentos e coma devagar</li>
            <li>• Evite beliscar entre as refeições</li>
            <li>• Se sentir fome fora dos horários, beba água ou chá sem açúcar</li>
            <li>• Em caso de dúvidas, use o chat com nossa IA</li>
          </ul>
        </div>

        {/* Substitutions */}
        <div className="bg-yellow-50 border border-yellow-200 p-6 rounded-lg">
          <h3 className="text-xl font-semibold text-yellow-800 mb-3">🔄 Substituições Permitidas</h3>
          <div className="grid md:grid-cols-2 gap-4 text-lg text-yellow-700">
            <div>
              <p><strong>Proteínas:</strong></p>
              <p>Frango → Peixe ou Ovo</p>
              <p>Peixe → Frango ou Tofu</p>
            </div>
            <div>
              <p><strong>Carboidratos:</strong></p>
              <p>Arroz integral → Quinoa</p>
              <p>Pão integral → Tapioca</p>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default MyPlanPage;