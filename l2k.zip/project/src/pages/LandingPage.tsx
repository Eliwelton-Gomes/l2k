import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, Shield, Clock, Users } from 'lucide-react';

const LandingPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <h1 className="text-2xl font-bold text-green-700">NutriVida 50+</h1>
            <div className="space-x-4">
              <Link
                to="/login"
                className="text-gray-700 hover:text-green-700 text-lg font-medium"
              >
                Entrar
              </Link>
              <Link
                to="/cadastro"
                className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 text-lg font-medium"
              >
                Cadastrar
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-b from-green-50 to-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-5xl font-bold text-gray-900 mb-6">
            Nutrição Inteligente para uma Vida Mais Saudável
          </h2>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Planos alimentares personalizados com inteligência artificial, 
            acompanhamento profissional e resultados rápidos para pessoas acima de 50 anos.
          </p>
          <Link
            to="/cadastro"
            className="bg-green-600 text-white px-8 py-4 rounded-lg hover:bg-green-700 text-xl font-medium inline-block"
          >
            Comece Agora Gratuitamente
          </Link>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h3 className="text-3xl font-bold text-center text-gray-900 mb-12">
            Por que escolher o NutriVida 50+?
          </h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="h-8 w-8 text-green-600" />
              </div>
              <h4 className="text-xl font-semibold text-gray-900 mb-2">Saúde em Primeiro Lugar</h4>
              <p className="text-gray-600">
                Planos seguros adaptados às suas condições de saúde e medicamentos.
              </p>
            </div>
            <div className="text-center">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="h-8 w-8 text-green-600" />
              </div>
              <h4 className="text-xl font-semibold text-gray-900 mb-2">Acompanhamento Profissional</h4>
              <p className="text-gray-600">
                Nutricionistas reais validam e ajustam suas recomendações.
              </p>
            </div>
            <div className="text-center">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="h-8 w-8 text-green-600" />
              </div>
              <h4 className="text-xl font-semibold text-gray-900 mb-2">Resultados Rápidos</h4>
              <p className="text-gray-600">
                Veja mudanças positivas em poucas semanas com nosso método.
              </p>
            </div>
            <div className="text-center">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="h-8 w-8 text-green-600" />
              </div>
              <h4 className="text-xl font-semibold text-gray-900 mb-2">Feito para Você</h4>
              <p className="text-gray-600">
                Interface simples e intuitiva, pensada especialmente para pessoas 50+.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-green-600 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h3 className="text-3xl font-bold text-white mb-4">
            Pronto para transformar sua alimentação?
          </h3>
          <p className="text-xl text-green-100 mb-8">
            Junte-se a milhares de pessoas que já mudaram suas vidas.
          </p>
          <Link
            to="/cadastro"
            className="bg-white text-green-600 px-8 py-4 rounded-lg hover:bg-gray-100 text-xl font-medium inline-block"
          >
            Criar Conta Gratuita
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-lg">&copy; 2024 NutriVida 50+. Todos os direitos reservados.</p>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;