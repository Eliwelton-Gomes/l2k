import React, { useState } from 'react';
import Layout from '../components/Layout';
import { HelpCircle, MessageCircle, Phone, Mail, ChevronDown, ChevronUp } from 'lucide-react';

const SupportPage: React.FC = () => {
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const [contactForm, setContactForm] = useState({
    subject: '',
    message: ''
  });

  const faqs = [
    {
      question: 'Como posso alterar meu plano alimentar?',
      answer: 'Você pode solicitar alterações no seu plano através do chat com nossa IA ou entrando em contato diretamente com nossa nutricionista. Mudanças são feitas baseadas em suas necessidades e progresso.'
    },
    {
      question: 'Com que frequência devo me pesar?',
      answer: 'Recomendamos se pesar uma vez por semana, sempre no mesmo dia e horário, preferencialmente pela manhã em jejum. Isso ajuda a acompanhar o progresso de forma mais precisa.'
    },
    {
      question: 'Posso fazer substituições nos alimentos?',
      answer: 'Sim! Você pode fazer substituições seguindo as orientações do seu plano ou perguntando para nossa IA. Sempre mantemos o equilíbrio nutricional nas substituições sugeridas.'
    },
    {
      question: 'E se eu não gostar de algum alimento do plano?',
      answer: 'Sem problemas! Entre em contato conosco e ajustaremos seu plano com alimentos que você goste e que atendam aos seus objetivos nutricionais.'
    },
    {
      question: 'Como funciona o acompanhamento com a nutricionista?',
      answer: 'Nossa nutricionista revisa seu progresso regularmente e está disponível para consultas quando necessário. Você pode solicitar uma conversa através do seu perfil.'
    },
    {
      question: 'Posso cancelar minha assinatura a qualquer momento?',
      answer: 'Sim, você pode cancelar sua assinatura a qualquer momento através do seu perfil, na seção "Assinatura". O cancelamento será efetivo no final do período já pago.'
    }
  ];

  const toggleFaq = (index: number) => {
    setOpenFaq(openFaq === index ? null : index);
  };

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simular envio
    alert('Mensagem enviada! Nossa equipe entrará em contato em até 24 horas.');
    setContactForm({ subject: '', message: '' });
  };

  return (
    <Layout>
      <div className="space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Central de Ajuda</h1>
          <p className="text-lg text-gray-600">Encontre respostas para suas dúvidas ou entre em contato conosco</p>
        </div>

        {/* Quick Contact */}
        <div className="grid md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 text-center">
            <div className="bg-green-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">
              <MessageCircle className="h-6 w-6 text-green-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Chat com IA</h3>
            <p className="text-gray-600 mb-4">Tire dúvidas rápidas sobre nutrição</p>
            <button className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
              Abrir Chat
            </button>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 text-center">
            <div className="bg-blue-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">
              <Phone className="h-6 w-6 text-blue-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Telefone</h3>
            <p className="text-gray-600 mb-4">Seg-Sex: 8h às 18h</p>
            <p className="text-lg font-semibold text-blue-600">(11) 3000-0000</p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 text-center">
            <div className="bg-purple-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">
              <Mail className="h-6 w-6 text-purple-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Email</h3>
            <p className="text-gray-600 mb-4">Resposta em até 24h</p>
            <p className="text-lg font-semibold text-purple-600">suporte@nutrivida50.com</p>
          </div>
        </div>

        {/* FAQ */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center space-x-3 mb-6">
            <HelpCircle className="h-6 w-6 text-gray-600" />
            <h2 className="text-2xl font-semibold text-gray-900">Perguntas Frequentes</h2>
          </div>

          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <div key={index} className="border border-gray-200 rounded-lg">
                <button
                  onClick={() => toggleFaq(index)}
                  className="w-full p-4 text-left flex items-center justify-between hover:bg-gray-50"
                >
                  <span className="text-lg font-medium text-gray-900">{faq.question}</span>
                  {openFaq === index ? (
                    <ChevronUp className="h-5 w-5 text-gray-500" />
                  ) : (
                    <ChevronDown className="h-5 w-5 text-gray-500" />
                  )}
                </button>
                {openFaq === index && (
                  <div className="p-4 border-t border-gray-200 bg-gray-50">
                    <p className="text-lg text-gray-700">{faq.answer}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Contact Form */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h2 className="text-2xl font-semibold text-gray-900 mb-6">Envie uma Mensagem</h2>
          
          <form onSubmit={handleContactSubmit} className="space-y-6">
            <div>
              <label className="block text-lg font-medium text-gray-700 mb-2">Assunto</label>
              <select
                value={contactForm.subject}
                onChange={(e) => setContactForm(prev => ({ ...prev, subject: e.target.value }))}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg text-lg"
                required
              >
                <option value="">Selecione um assunto</option>
                <option value="plano-alimentar">Dúvidas sobre plano alimentar</option>
                <option value="conta">Problemas com minha conta</option>
                <option value="pagamento">Questões de pagamento</option>
                <option value="tecnico">Problema técnico</option>
                <option value="sugestao">Sugestão ou feedback</option>
                <option value="outro">Outro</option>
              </select>
            </div>

            <div>
              <label className="block text-lg font-medium text-gray-700 mb-2">Mensagem</label>
              <textarea
                value={contactForm.message}
                onChange={(e) => setContactForm(prev => ({ ...prev, message: e.target.value }))}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg text-lg"
                rows={6}
                placeholder="Descreva sua dúvida ou problema em detalhes..."
                required
              />
            </div>

            <button
              type="submit"
              className="w-full bg-green-600 text-white py-3 px-4 rounded-lg hover:bg-green-700 text-lg font-medium"
            >
              Enviar Mensagem
            </button>
          </form>
        </div>

        {/* Emergency Contact */}
        <div className="bg-red-50 border border-red-200 p-6 rounded-lg">
          <h3 className="text-xl font-semibold text-red-800 mb-2">⚠️ Emergência Médica</h3>
          <p className="text-lg text-red-700">
            Em caso de emergência médica, procure imediatamente um hospital ou ligue para o SAMU (192). 
            Nossa equipe não substitui atendimento médico de emergência.
          </p>
        </div>
      </div>
    </Layout>
  );
};

export default SupportPage;