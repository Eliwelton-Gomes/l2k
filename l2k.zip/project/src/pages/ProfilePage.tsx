import React, { useState } from 'react';
import Layout from '../components/Layout';
import { useAuth } from '../contexts/AuthContext';
import { User, Mail, Phone, Bell, Shield, CreditCard, LogOut } from 'lucide-react';

const ProfilePage: React.FC = () => {
  const { user, logout } = useAuth();
  const [notifications, setNotifications] = useState({
    mealReminders: true,
    weightTracking: true,
    nutritionistMessages: true,
    weeklyReports: false
  });

  const handleNotificationChange = (key: string, value: boolean) => {
    setNotifications(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const handleLogout = () => {
    if (confirm('Tem certeza que deseja sair?')) {
      logout();
    }
  };

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Meu Perfil</h1>
          <p className="text-lg text-gray-600">Gerencie suas informações pessoais e configurações</p>
        </div>

        {/* Personal Information */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h2 className="text-2xl font-semibold text-gray-900 mb-6">Informações Pessoais</h2>
          
          <div className="space-y-4">
            <div className="flex items-center space-x-4">
              <div className="bg-green-100 p-3 rounded-full">
                <User className="h-6 w-6 text-green-600" />
              </div>
              <div className="flex-1">
                <label className="block text-lg font-medium text-gray-700">Nome Completo</label>
                <input
                  type="text"
                  value={user?.name || ''}
                  readOnly
                  className="mt-1 w-full px-4 py-3 border border-gray-300 rounded-lg bg-gray-50 text-lg"
                />
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <div className="bg-blue-100 p-3 rounded-full">
                <Mail className="h-6 w-6 text-blue-600" />
              </div>
              <div className="flex-1">
                <label className="block text-lg font-medium text-gray-700">Email</label>
                <input
                  type="email"
                  value={user?.email || ''}
                  readOnly
                  className="mt-1 w-full px-4 py-3 border border-gray-300 rounded-lg bg-gray-50 text-lg"
                />
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <div className="bg-purple-100 p-3 rounded-full">
                <Phone className="h-6 w-6 text-purple-600" />
              </div>
              <div className="flex-1">
                <label className="block text-lg font-medium text-gray-700">Telefone</label>
                <input
                  type="tel"
                  value={user?.phone || ''}
                  readOnly
                  className="mt-1 w-full px-4 py-3 border border-gray-300 rounded-lg bg-gray-50 text-lg"
                />
              </div>
            </div>
          </div>

          <div className="mt-6">
            <p className="text-gray-600 text-lg">
              Para alterar suas informações pessoais, entre em contato com nossa equipe de suporte.
            </p>
          </div>
        </div>

        {/* Health Data Summary */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h2 className="text-2xl font-semibold text-gray-900 mb-6">Dados de Saúde</h2>
          
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-medium text-gray-700 mb-3">Informações Básicas</h3>
              <div className="space-y-2 text-lg text-gray-600">
                <p>Idade: 55 anos</p>
                <p>Altura: 165 cm</p>
                <p>Peso atual: 72 kg</p>
                <p>Meta: 65 kg</p>
              </div>
            </div>
            <div>
              <h3 className="text-lg font-medium text-gray-700 mb-3">Condições de Saúde</h3>
              <div className="space-y-2 text-lg text-gray-600">
                <p>Hipertensão controlada</p>
                <p>Sem alergias alimentares</p>
                <p>Atividade física: Leve</p>
              </div>
            </div>
          </div>

          <div className="mt-6">
            <button className="text-green-600 hover:text-green-700 text-lg font-medium">
              Solicitar atualização dos dados de saúde
            </button>
          </div>
        </div>

        {/* Notifications */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center space-x-3 mb-6">
            <Bell className="h-6 w-6 text-gray-600" />
            <h2 className="text-2xl font-semibold text-gray-900">Notificações</h2>
          </div>
          
          <div className="space-y-4">
            {[
              { key: 'mealReminders', label: 'Lembretes de refeições', description: 'Receba notificações nos horários das refeições' },
              { key: 'weightTracking', label: 'Acompanhamento de peso', description: 'Lembretes para registrar seu peso semanalmente' },
              { key: 'nutritionistMessages', label: 'Mensagens da nutricionista', description: 'Notificações quando receber mensagens da equipe' },
              { key: 'weeklyReports', label: 'Relatórios semanais', description: 'Resumo semanal do seu progresso por email' }
            ].map((item) => (
              <div key={item.key} className="flex items-center justify-between py-3 border-b border-gray-100 last:border-b-0">
                <div className="flex-1">
                  <h3 className="text-lg font-medium text-gray-900">{item.label}</h3>
                  <p className="text-gray-600">{item.description}</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={notifications[item.key as keyof typeof notifications]}
                    onChange={(e) => handleNotificationChange(item.key, e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-green-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
                </label>
              </div>
            ))}
          </div>
        </div>

        {/* Security & Privacy */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center space-x-3 mb-6">
            <Shield className="h-6 w-6 text-gray-600" />
            <h2 className="text-2xl font-semibold text-gray-900">Segurança e Privacidade</h2>
          </div>
          
          <div className="space-y-4">
            <button className="w-full text-left p-4 border border-gray-200 rounded-lg hover:bg-gray-50">
              <h3 className="text-lg font-medium text-gray-900">Alterar Senha</h3>
              <p className="text-gray-600">Atualize sua senha para manter sua conta segura</p>
            </button>
            
            <button className="w-full text-left p-4 border border-gray-200 rounded-lg hover:bg-gray-50">
              <h3 className="text-lg font-medium text-gray-900">Política de Privacidade</h3>
              <p className="text-gray-600">Veja como protegemos seus dados pessoais</p>
            </button>
          </div>
        </div>

        {/* Subscription */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center space-x-3 mb-6">
            <CreditCard className="h-6 w-6 text-gray-600" />
            <h2 className="text-2xl font-semibold text-gray-900">Assinatura</h2>
          </div>
          
          <div className="bg-green-50 border border-green-200 p-4 rounded-lg mb-4">
            <h3 className="text-lg font-semibold text-green-800">Plano Premium Ativo</h3>
            <p className="text-green-700">Próxima cobrança: 25 de Janeiro de 2024</p>
            <p className="text-green-700">R$ 49,90/mês</p>
          </div>
          
          <div className="space-y-3">
            <button className="text-green-600 hover:text-green-700 text-lg font-medium">
              Gerenciar assinatura
            </button>
            <br />
            <button className="text-red-600 hover:text-red-700 text-lg font-medium">
              Cancelar assinatura
            </button>
          </div>
        </div>

        {/* Logout */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <button
            onClick={handleLogout}
            className="flex items-center space-x-3 text-red-600 hover:text-red-700 text-lg font-medium"
          >
            <LogOut className="h-6 w-6" />
            <span>Sair da Conta</span>
          </button>
        </div>
      </div>
    </Layout>
  );
};

export default ProfilePage;