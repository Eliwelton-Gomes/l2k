import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUser } from '../contexts/UserContext';
import { useAuth } from '../contexts/AuthContext';
import { ChevronRight, ChevronLeft } from 'lucide-react';

const OnboardingPage: React.FC = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    age: '',
    gender: '',
    height: '',
    currentWeight: '',
    targetWeight: '',
    healthConditions: [] as string[],
    medications: '',
    allergies: '',
    dietaryPreferences: [] as string[],
    physicalLimitations: '',
    activityLevel: '',
    currentHabits: '',
    weightLossTimeframe: ''
  });

  const { updateHealthData, completeOnboarding } = useUser();
  const { user } = useAuth();
  const navigate = useNavigate();

  const totalSteps = 5;

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleArrayChange = (field: string, value: string, checked: boolean) => {
    setFormData(prev => ({
      ...prev,
      [field]: checked 
        ? [...(prev[field as keyof typeof prev] as string[]), value]
        : (prev[field as keyof typeof prev] as string[]).filter(item => item !== value)
    }));
  };

  const nextStep = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmit = () => {
    const healthData = {
      age: parseInt(formData.age),
      gender: formData.gender as 'masculino' | 'feminino',
      height: parseInt(formData.height),
      currentWeight: parseInt(formData.currentWeight),
      targetWeight: parseInt(formData.targetWeight),
      healthConditions: formData.healthConditions,
      medications: formData.medications.split(',').map(m => m.trim()).filter(m => m),
      allergies: formData.allergies.split(',').map(a => a.trim()).filter(a => a),
      dietaryPreferences: formData.dietaryPreferences,
      physicalLimitations: formData.physicalLimitations.split(',').map(l => l.trim()).filter(l => l),
      activityLevel: formData.activityLevel as 'sedentario' | 'leve' | 'moderado' | 'intenso',
      currentHabits: formData.currentHabits,
      weightLossTimeframe: formData.weightLossTimeframe
    };

    updateHealthData(healthData);
    completeOnboarding();
    navigate('/dashboard');
  };

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-6">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">Informações Básicas</h3>
            
            <div>
              <label className="block text-lg font-medium text-gray-700 mb-2">Idade</label>
              <input
                type="number"
                value={formData.age}
                onChange={(e) => handleInputChange('age', e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg text-lg"
                placeholder="Ex: 55"
                min="50"
                max="100"
              />
            </div>

            <div>
              <label className="block text-lg font-medium text-gray-700 mb-2">Sexo</label>
              <div className="space-y-2">
                {['masculino', 'feminino'].map(option => (
                  <label key={option} className="flex items-center">
                    <input
                      type="radio"
                      name="gender"
                      value={option}
                      checked={formData.gender === option}
                      onChange={(e) => handleInputChange('gender', e.target.value)}
                      className="mr-3 h-5 w-5 text-green-600"
                    />
                    <span className="text-lg capitalize">{option}</span>
                  </label>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-lg font-medium text-gray-700 mb-2">Altura (cm)</label>
              <input
                type="number"
                value={formData.height}
                onChange={(e) => handleInputChange('height', e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg text-lg"
                placeholder="Ex: 165"
                min="140"
                max="220"
              />
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">Peso e Objetivos</h3>
            
            <div>
              <label className="block text-lg font-medium text-gray-700 mb-2">Peso Atual (kg)</label>
              <input
                type="number"
                value={formData.currentWeight}
                onChange={(e) => handleInputChange('currentWeight', e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg text-lg"
                placeholder="Ex: 75"
                min="40"
                max="200"
              />
            </div>

            <div>
              <label className="block text-lg font-medium text-gray-700 mb-2">Peso Desejado (kg)</label>
              <input
                type="number"
                value={formData.targetWeight}
                onChange={(e) => handleInputChange('targetWeight', e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg text-lg"
                placeholder="Ex: 65"
                min="40"
                max="200"
              />
            </div>

            <div>
              <label className="block text-lg font-medium text-gray-700 mb-2">Em quanto tempo gostaria de atingir seu objetivo?</label>
              <select
                value={formData.weightLossTimeframe}
                onChange={(e) => handleInputChange('weightLossTimeframe', e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg text-lg"
              >
                <option value="">Selecione...</option>
                <option value="1-3 meses">1 a 3 meses</option>
                <option value="3-6 meses">3 a 6 meses</option>
                <option value="6-12 meses">6 a 12 meses</option>
                <option value="mais de 1 ano">Mais de 1 ano</option>
              </select>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">Condições de Saúde</h3>
            
            <div>
              <label className="block text-lg font-medium text-gray-700 mb-3">Possui alguma dessas condições? (Marque todas que se aplicam)</label>
              <div className="space-y-2">
                {[
                  'Diabetes',
                  'Hipertensão',
                  'Colesterol alto',
                  'Problemas cardíacos',
                  'Problemas na tireoide',
                  'Artrite/Artrose',
                  'Osteoporose',
                  'Nenhuma das anteriores'
                ].map(condition => (
                  <label key={condition} className="flex items-center">
                    <input
                      type="checkbox"
                      checked={formData.healthConditions.includes(condition)}
                      onChange={(e) => handleArrayChange('healthConditions', condition, e.target.checked)}
                      className="mr-3 h-5 w-5 text-green-600"
                    />
                    <span className="text-lg">{condition}</span>
                  </label>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-lg font-medium text-gray-700 mb-2">Medicamentos em uso</label>
              <textarea
                value={formData.medications}
                onChange={(e) => handleInputChange('medications', e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg text-lg"
                placeholder="Liste os medicamentos que você toma regularmente (separe por vírgula)"
                rows={3}
              />
            </div>

            <div>
              <label className="block text-lg font-medium text-gray-700 mb-2">Alergias ou Intolerâncias Alimentares</label>
              <textarea
                value={formData.allergies}
                onChange={(e) => handleInputChange('allergies', e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg text-lg"
                placeholder="Ex: lactose, glúten, amendoim (separe por vírgula)"
                rows={3}
              />
            </div>
          </div>
        );

      case 4:
        return (
          <div className="space-y-6">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">Preferências Alimentares</h3>
            
            <div>
              <label className="block text-lg font-medium text-gray-700 mb-3">Tipo de dieta preferida (Marque todas que se aplicam)</label>
              <div className="space-y-2">
                {[
                  'Tradicional (sem restrições)',
                  'Low carb',
                  'Vegetariana',
                  'Mediterrânea',
                  'Rica em fibras',
                  'Pobre em sódio'
                ].map(diet => (
                  <label key={diet} className="flex items-center">
                    <input
                      type="checkbox"
                      checked={formData.dietaryPreferences.includes(diet)}
                      onChange={(e) => handleArrayChange('dietaryPreferences', diet, e.target.checked)}
                      className="mr-3 h-5 w-5 text-green-600"
                    />
                    <span className="text-lg">{diet}</span>
                  </label>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-lg font-medium text-gray-700 mb-2">Nível de atividade física</label>
              <div className="space-y-2">
                {[
                  { value: 'sedentario', label: 'Sedentário (pouco ou nenhum exercício)' },
                  { value: 'leve', label: 'Leve (exercício leve 1-3 dias/semana)' },
                  { value: 'moderado', label: 'Moderado (exercício moderado 3-5 dias/semana)' },
                  { value: 'intenso', label: 'Intenso (exercício pesado 6-7 dias/semana)' }
                ].map(option => (
                  <label key={option.value} className="flex items-center">
                    <input
                      type="radio"
                      name="activityLevel"
                      value={option.value}
                      checked={formData.activityLevel === option.value}
                      onChange={(e) => handleInputChange('activityLevel', e.target.value)}
                      className="mr-3 h-5 w-5 text-green-600"
                    />
                    <span className="text-lg">{option.label}</span>
                  </label>
                ))}
              </div>
            </div>
          </div>
        );

      case 5:
        return (
          <div className="space-y-6">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">Últimas Informações</h3>
            
            <div>
              <label className="block text-lg font-medium text-gray-700 mb-2">Limitações físicas ou dificuldades</label>
              <textarea
                value={formData.physicalLimitations}
                onChange={(e) => handleInputChange('physicalLimitations', e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg text-lg"
                placeholder="Ex: dificuldade para mastigar, problemas de deglutição, limitações de mobilidade"
                rows={3}
              />
            </div>

            <div>
              <label className="block text-lg font-medium text-gray-700 mb-2">Descreva seus hábitos alimentares atuais</label>
              <textarea
                value={formData.currentHabits}
                onChange={(e) => handleInputChange('currentHabits', e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg text-lg"
                placeholder="Ex: como muitos doces, pulo o café da manhã, como muito à noite..."
                rows={4}
              />
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-2xl mx-auto px-4">
        <div className="bg-white rounded-lg shadow-lg p-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-green-700 mb-2">Bem-vindo(a), {user?.name}!</h1>
            <p className="text-lg text-gray-600">
              Vamos conhecer você melhor para criar o plano alimentar perfeito.
            </p>
          </div>

          {/* Progress Bar */}
          <div className="mb-8">
            <div className="flex justify-between items-center mb-2">
              <span className="text-lg font-medium text-gray-700">Etapa {currentStep} de {totalSteps}</span>
              <span className="text-lg text-gray-500">{Math.round((currentStep / totalSteps) * 100)}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-3">
              <div 
                className="bg-green-600 h-3 rounded-full transition-all duration-300"
                style={{ width: `${(currentStep / totalSteps) * 100}%` }}
              ></div>
            </div>
          </div>

          {/* Form Content */}
          <div className="mb-8">
            {renderStep()}
          </div>

          {/* Navigation Buttons */}
          <div className="flex justify-between">
            <button
              onClick={prevStep}
              disabled={currentStep === 1}
              className="flex items-center px-6 py-3 text-lg font-medium text-gray-600 bg-gray-100 rounded-lg hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <ChevronLeft className="h-5 w-5 mr-2" />
              Anterior
            </button>

            {currentStep === totalSteps ? (
              <button
                onClick={handleSubmit}
                className="flex items-center px-6 py-3 text-lg font-medium text-white bg-green-600 rounded-lg hover:bg-green-700"
              >
                Finalizar
                <ChevronRight className="h-5 w-5 ml-2" />
              </button>
            ) : (
              <button
                onClick={nextStep}
                className="flex items-center px-6 py-3 text-lg font-medium text-white bg-green-600 rounded-lg hover:bg-green-700"
              >
                Próximo
                <ChevronRight className="h-5 w-5 ml-2" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default OnboardingPage;